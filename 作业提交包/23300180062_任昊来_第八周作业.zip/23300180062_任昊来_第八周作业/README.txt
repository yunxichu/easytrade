期货期权1分钟数据 IV/RV、希腊字母与价格归因作业包

主要文件：
1. 23300180062_任昊来_第八周作业.docx：正式Word作业报告。
2. 23300180062_任昊来_第八周作业.pdf：正式PDF作业报告。
3. code/prepare_quantconnect_es_option_data.py：下载并转换公开样本数据。
4. code/option_iv_rv_greeks.py：计算IV、RV、历史分位、希腊字母和价格归因。
5. code/prepare_historical_percentiles.py：用Yahoo ES=F和VIX历史数据计算历史分位代理。
6. code/generate_option_homework_report.py：生成DOCX/PDF和本提交包。
7. data/：原始公开样本zip、处理后的分钟CSV和Yahoo历史CSV。
8. outputs/：计算结果表和图形。

复现命令：
python research/prepare_quantconnect_es_option_data.py
python research/option_iv_rv_greeks.py --input data/processed/quantconnect_es_future_option_minute.csv --output-dir research/outputs/es_options --rv-window 60 --percentile-window 390 --minutes-per-year 347760 --rate 0.015
python research/prepare_historical_percentiles.py
python research/generate_option_homework_report.py

当前提交命名：23300180062_任昊来_第八周作业