第十周 Project：历史期权数据再现 + 日线仿真交易策略回测

提交名称：23300180062_任昊来_第十周Project

项目目标：
1. 在缺乏免费完整历史期权链数据的情况下，
   用 Black-Scholes 模型 + 实现波动率拟合 IV 曲面，
   从标的资产日线价格再现 2024-2026 两年的虚拟期权链。
2. 设计并回测一个仿真交易策略：滚动卖出 30 天到期、0.20 delta 的宽跨（Short Strangle），
   含开仓阈值、止盈 (50%)、止损 (200%)、管理期 (DTE=2) 退出规则。
3. 多维度量化损益和风险：净值曲线、回撤、交易级 P&L 分布、
   日度 Greeks 暴露、与买入持有的对比。

主要文件：
- 23300180062_任昊来_第十周Project.pdf：PDF 报告
- 23300180062_任昊来_第十周Project.docx：Word 报告
- code/week10_project_backtest.py：完整回测引擎（数据 → IV 曲面 → 策略 → 风控 → 统计）
- code/generate_week10_project_report.py：本报告生成器
- data/：标的资产历史与 RV 加工后的数据
- outputs/：净值、交易、统计表、所有图形

关键统计：
- 回测窗口：2024-06-06 → 2026-05-12 (484 天)
- 总交易次数：32，胜率：75.0%
- 策略 CAGR：-0.16% vs 买入持有 CAGR：20.35%
- 最大回撤：-3.89%，Sharpe：-0.03

复现命令：
python research/week10_project_backtest.py
python research/generate_week10_project_report.py