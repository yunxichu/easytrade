wisecoin_option程序分析与组合策略扩展作业包

提交名称：23300180062_任昊来_第九周作业

主要内容：
1. 分析wisecoin_option类程序的数据下载流程和观点形成逻辑。
2. 新增模块A：组合策略希腊字母计算。
3. 新增模块B：策略盈亏分析，包括
   - 到期盈亏曲线（161点）
   - 7天后价格×IV情景重估热力图
   - 1/7/14/21天多时间断面情景
   - 风险中性 + 真实世界双假设的Monte Carlo模拟（20000路径）
     给出POP、期望盈亏、VaR95、CVaR95

主要文件：
- 23300180062_任昊来_第九周作业.docx：Word报告。
- 23300180062_任昊来_第九周作业.pdf：PDF报告。
- code/wisecoin_option_analysis.py：数据下载、观点形成、组合Greeks、所有盈亏分析。
- code/generate_wisecoin_option_homework_report.py：生成报告和提交包。
- data/：Yahoo/yfinance下载的SPY历史数据和期权链。
- outputs/：策略腿、组合Greeks、盈亏表、观点摘要和图形（共6张）。

复现命令：
python research/wisecoin_option_analysis.py
python research/generate_wisecoin_option_homework_report.py