第十周作业：期权VIX指数复现 + 原油期权策略

提交名称：23300180062_任昊来_第十周作业

主要内容：
1. 题1：CBOE VIX白皮书方法 - 复现SPY的VIX与USO的OVX指数。
2. 题2：对原油期权 USO 执行四种交易策略，分析到期日的损益和风险。
   - 卖出跨式（Short Straddle）
   - 卖出宽跨（Short Strangle）
   - 铁鹰（Iron Condor）
   - 日历价差（Calendar Spread）

主要文件：
- 23300180062_任昊来_第十周作业.pdf：PDF 报告
- 23300180062_任昊来_第十周作业.docx：Word 报告
- code/week10_vix_calculator.py：VIX 计算引擎（CBOE方法）
- code/week10_oil_strategy.py：四策略对比分析
- code/generate_week10_homework_report.py：本报告生成器
- data/spy_chain.csv, uso_chain.csv：下载的期权链
- outputs/：所有 CSV / JSON / PNG 输出

复现命令：
python research/week10_vix_calculator.py
python research/week10_oil_strategy.py
python research/generate_week10_homework_report.py